const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const ignored = new Set(['node_modules', '.git', 'tmp', 'sticker']);
const files = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory() && ignored.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.isFile() && full.endsWith('.js')) files.push(full);
  }
}
walk(root);
let failed = 0;
for (const file of files) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) {
    failed++;
    process.stderr.write(`\nSyntax error: ${path.relative(root, file)}\n${result.stderr || result.stdout}`);
  }
}
if (failed) {
  console.error(`\n${failed}/${files.length} JavaScript files failed syntax checks.`);
  process.exit(1);
}
console.log(`Syntax OK: ${files.length} JavaScript files checked.`);
