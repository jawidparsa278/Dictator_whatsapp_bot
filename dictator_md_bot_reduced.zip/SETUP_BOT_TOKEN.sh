#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f package.json ]]; then
  echo "Run this script from the bot project root (the folder containing package.json)." >&2
  exit 1
fi

read -r -s -p "Telegram bot token (input hidden): " BOT_TOKEN
printf '\n'
if [[ -z "$BOT_TOKEN" ]]; then
  echo "No token entered; nothing was changed." >&2
  exit 1
fi

umask 077
tmp_file="$(mktemp .env.XXXXXX)"
trap 'rm -f "$tmp_file"' EXIT
if [[ -f .env ]]; then
  grep -vE '^(BOT_TOKEN|ENABLE_OWNER_EVAL)=' .env > "$tmp_file" || true
fi
printf 'BOT_TOKEN=%s\nENABLE_OWNER_EVAL=false\n' "$BOT_TOKEN" >> "$tmp_file"
chmod 600 "$tmp_file"
mv "$tmp_file" .env
trap - EXIT
unset BOT_TOKEN
chmod 600 .env

echo "Token saved in .env with owner-only file permissions; it was not printed."
if [[ ! -d node_modules ]]; then
  echo "Dependencies are not installed. This script did not install packages or start the bot."
  echo "After reviewing dependencies, install them with npm ci, then run this script again."
  exit 0
fi
read -r -p "Start Telegram polling now? Stop any existing bot process first. [y/N] " answer
case "$answer" in
  y|Y|yes|YES) exec npm start ;;
  *) echo "Saved only. Start later with npm start from this project folder." ;;
esac
