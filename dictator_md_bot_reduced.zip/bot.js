require('dotenv').config();
require('./setting/config');
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs').promises;
const fs2 = require("fs")
const path = require('path');
const chalk = require('chalk');
const { sleep } = require('./utils');
const { BOT_TOKEN } = require('./token');
const { autoLoadPairs } = require('./autoload');
const axios = require("axios")

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const adminFilePath = path.join(__dirname, 'kingbadboitimewisher', 'admin.json');
const usersFilePath = path.join(__dirname, 'database', 'users.json');
const pairingOwnersFilePath = path.join(__dirname, 'database', 'pairingOwners.json');
let adminIDs = [];
let userList = [];

// Pairing ownership and request throttling are scoped to Telegram accounts.
const userStates = new Map();
const pairingCooldowns = new Map();
function readPairingOwners() {
  try {
    const value = JSON.parse(fs2.readFileSync(pairingOwnersFilePath, 'utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch { return {}; }
}
function savePairingOwner(jid, telegramUserId) {
  const owners = readPairingOwners();
  owners[jid] = String(telegramUserId);
  fs2.mkdirSync(path.dirname(pairingOwnersFilePath), { recursive: true, mode: 0o700 });
  const temp = `${pairingOwnersFilePath}.${process.pid}.tmp`;
  fs2.writeFileSync(temp, JSON.stringify(owners, null, 2), { mode: 0o600 });
  fs2.renameSync(temp, pairingOwnersFilePath);
  try { fs2.chmodSync(pairingOwnersFilePath, 0o600); } catch (_) {}
}
function removePairingOwner(jid) {
  const owners = readPairingOwners();
  delete owners[jid];
  fs2.writeFileSync(pairingOwnersFilePath, JSON.stringify(owners, null, 2), { mode: 0o600 });
  try { fs2.chmodSync(pairingOwnersFilePath, 0o600); } catch (_) {}
}
function pairingCooldownRemaining(userId) {
  const now = Date.now();
  const key = String(userId);
  const until = pairingCooldowns.get(key) || 0;
  if (until > now) return until - now;
  pairingCooldowns.set(key, now + 30_000);
  return 0;
}
function canManagePairing(telegramUserId, jid) {
  return adminIDs.some(id => String(id) === String(telegramUserId)) ||
    String(readPairingOwners()[jid] || '') === String(telegramUserId);
}

const loadUsers = async () => {
  if (!(await exists(usersFilePath))) {
    await fs.writeFile(usersFilePath, JSON.stringify([], null, 2));
    userList = [];
  } else {
    try {
      const raw = await fs.readFile(usersFilePath, 'utf8');
      userList = JSON.parse(raw);
    } catch (err) {
      userList = [];
    }
  }
};

const exists = async (filePath) => {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
};

const loadAdminIDs = async () => {
  const ownerID = '8204959327';
  const defaultAdmins = [ownerID];

  if (!(await exists(adminFilePath))) {
    await fs.writeFile(adminFilePath, JSON.stringify(defaultAdmins, null, 2));
    adminIDs = defaultAdmins;
    console.log('✅ Created admin.json with default owner ID');
  } else {
    try {
      const raw = await fs.readFile(adminFilePath, 'utf8');
      adminIDs = JSON.parse(raw);
    } catch (err) {
      console.error('Error loading admin.json:', err);
      adminIDs = defaultAdmins;
    }
  }
  console.log(`✅ Loaded ${adminIDs.length} Telegram admin account(s).`);
};

let isShuttingDown = false;
let isAutoLoadRunning = false;

const runAutoLoad = async () => {
  if (isAutoLoadRunning || isShuttingDown) return;
  isAutoLoadRunning = true;

  try {
    console.log('⏱️ INITIATING AUTO-LOAD');
    await autoLoadPairs();
    console.log('✅ AUTO-LOAD COMPLETED');
  } catch (e) {
    console.error('❌ AUTO-LOAD FAILED:', e);
  } finally {
    isAutoLoadRunning = false;
  }
};

const startAutoLoadLoop = () => {
  runAutoLoad();
  setInterval(runAutoLoad, 60 * 60 * 1000);
};
startAutoLoadLoop();

const gracefulShutdown = (signal) => {
  if (isShuttingDown) return;
  isShuttingDown = true;
  
  console.log(`🛑 Received ${signal}. Shutting down gracefully...`);
  bot.stopPolling();
  console.log('✅ Bot stopped successfully');
  process.exit(0);
};

// ========== CHECK CHANNELS FUNCTION ==========
const checkUserJoinedChannels = async (userId) => {
  const channels = ['@Afghan_Tech_910', '@AFG_HACK_1387'];
  let allJoined = true;

  for (const channel of channels) {
    try {
      const member = await bot.getChatMember(channel, userId);
      if (['left', 'kicked'].includes(member.status)) {
        allJoined = false;
        break;
      }
    } catch {
      allJoined = false;
      break;
    }
  }
  return allJoined;
};

// ========== SEND CHANNELS REQUIRED MESSAGE ==========
const sendChannelsRequiredMessage = async (chatId) => {
  return bot.sendMessage(chatId,
    `🚨 *You must join our official channels before pairing.*`,
    {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '📢 Channel 1', url: 'https://t.me/Afghan_Tech_910' }],
          [{ text: '📢 Channel 2', url: 'https://t.me/AFG_HACK_1387' }],
          [{ text: '✅ I have joined', callback_data: 'check_join' }]
        ]
      }
    }
  );
};

// ========== SEND GROUP MESSAGE (STYLISH) ==========
const sendGroupMessage = async (chatId, replyToMessageId = null) => {
  const botInfo = await bot.getMe();
  const botUsername = botInfo.username;
  
  const message = `╭━━〔 🛡️ 𝙑𝙄𝙋 𝙎𝙀𝘾𝙐𝙍𝙀 〕━━╮
➤ Use in DM 👇
╰━━〔 🚀 𝙎𝙏𝘼𝙍𝙏 𝙉𝙊𝙒 〕━━╯`;

  const options = {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [{ text: '🚀 START NOW', url: `https://t.me/${botUsername}?start=pair` }]
      ]
    }
  };

  if (replyToMessageId) {
    options.reply_to_message_id = replyToMessageId;
  }

  return bot.sendMessage(chatId, message, options);
};

// ========== START COMMAND ==========
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isGroup = msg.chat.type === 'group' || msg.chat.type === 'supergroup';

  if (isGroup) {
    return sendGroupMessage(chatId, msg.message_id);
  }

  // Track user
  if (!userList.includes(userId)) {
    userList.push(userId);
    await fs.writeFile(usersFilePath, JSON.stringify(userList, null, 2));
    
    // Notify Admin
    const name = msg.from.first_name + (msg.from.last_name ? ' ' + msg.from.last_name : '');
    const username = msg.from.username ? `@${msg.from.username}` : 'No Username';
    const notifyMsg = `🆕 *New User Started the Bot!*\n\n👤 *Name:* ${name}\n🆔 *ID:* ${userId}\n🔗 *Username:* ${username}`;
    
    for (const adminId of adminIDs) {
      try {
        await bot.sendMessage(adminId, notifyMsg, { parse_mode: 'Markdown' });
      } catch (e) {
        console.error(`Failed to notify admin ${adminId}:`, e.message);
      }
    }
  }

  const totalUsers = userList.length;

  // Private chat mein normal start message
  await bot.sendPhoto(
    chatId,
    "./media/bot-brand.png",
    {
      caption: `🪀 *𝙏𝙝𝙚 ꨄ 𝐃𝐈𝐂𝐓𝐀𝐓𝐎𝐑 𝙆𝙞𝙣𝙜 𝙏𝙚𝙘𝙝 𝙈𝘿 ꨄ*\n\n╔════════════════════╗\n ⤷ /pair <wa_number>\n ⤷ /unpair <wa_number>\n╚════════════════════╝\n\n📊 *Total Users:* ${totalUsers}`,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: "👑 Owner", url: "https://t.me/PV_Parwani_4k" }]
        ]
      }
    }
  );
});

// ========== PAIR COMMAND ==========
bot.onText(/\/pair(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isGroup = msg.chat.type === 'group' || msg.chat.type === 'supergroup';
  const text = match[1]?.trim();

  // 🔥 GROUP MEIN /pair LIKHA TO SAME STYLISH MESSAGE (JAISE START MEIN HAI)
  if (isGroup) {
    return sendGroupMessage(chatId, msg.message_id);
  }

  // 🔥 PRIVATE CHAT MEIN NORMAL PAIRING PROCESS
  const allJoined = await checkUserJoinedChannels(userId);
  
  if (!allJoined) {
    return sendChannelsRequiredMessage(chatId);
  }

  if (!text) {
    userStates.set(userId, { step: 'awaiting_number' });
    return bot.sendMessage(chatId, 
      `🔐 *Please send your WhatsApp number*\n\nExample: /pair 93xxxxxxxxx\n\nOr just type: 93xxxxxxxxx`,
      { parse_mode: 'Markdown' }
    );
  }

  if (/[a-z]/i.test(text)) {
    return bot.sendMessage(chatId, '❌ *Letters are not allowed.*\n\nPlease send only numbers.', { parse_mode: 'Markdown' });
  }
  
  if (!/^\d{7,15}$/.test(text)) {
    return bot.sendMessage(chatId, '❌ *Invalid format.*\n\nPlease send a valid WhatsApp number.\nExample: 93xxxxxxxxx', { parse_mode: 'Markdown' });
  }
  
  if (text.startsWith('0')) {
    return bot.sendMessage(chatId, '❌ *Numbers starting with 0 are not allowed.*\n\nPlease include country code.', { parse_mode: 'Markdown' });
  }

  const countryCode = text.slice(0, 3);
  if (["252", "201"].includes(countryCode)) {
    return bot.sendMessage(chatId, '❌ *Numbers with this country code are not supported.*', { parse_mode: 'Markdown' });
  }

  const cooldownLeft = pairingCooldownRemaining(userId);
  if (cooldownLeft > 0) return bot.sendMessage(chatId, 'لطفاً پیش از درخواست دوباره کمی صبر کنید.');

  const pairingFolder = path.join(__dirname, 'kingbadboitimewisher', 'pairing');
  if (!(await exists(pairingFolder))) {
    await fs.mkdir(pairingFolder, { recursive: true });
  }

  const files = await fs.readdir(pairingFolder);
  const pairedCount = files.filter(f => f.endsWith('@s.whatsapp.net')).length;

  if (pairedCount >= 1000) {
    return bot.sendMessage(chatId, '❌ *Pairing limit reached.*\n\nPlease try again later.', { parse_mode: 'Markdown' });
  }

  userStates.delete(userId);

  try {
    const startpairing = require('./pair.js');
    const Xreturn = text + "@s.whatsapp.net";

    await bot.sendMessage(chatId, '⏳ *Generating pairing code...*\n\nPlease wait a moment.', { parse_mode: 'Markdown' });
    
    const socket = await startpairing(Xreturn);
    const cuObj = await socket.pairingCode;
    if (!cuObj || cuObj.number !== Xreturn) throw new Error('Pairing code unavailable for this request.');
    savePairingOwner(Xreturn, userId);

    return bot.sendMessage(chatId,
      `🔗 *Pairing Code for WhatsApp*\n\n` +
      `📝 *Code:* 👉 \`${cuObj.code}\` 👈\n\n` +
      `➡️ *Instructions:*\n` +
      `1. Open WhatsApp\n` +
      `2. Go to Settings → Linked Devices\n` +
      `3. Tap "Link a Device"\n` +
      `4. Enter this code\n\n` +
      `⚠️ *Code expires in 2 minutes*`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: `Pairing system`, callback_data: `pairing_system` }]
          ]
        }
      }
    );

  } catch (error) {
    console.error('PAIR COMMAND ERROR:', error);
    bot.sendMessage(chatId, '❌ *Pairing service is temporarily unavailable.*\n\nPlease try again later.', { parse_mode: 'Markdown' });
  }
});

// ========== CALLBACK QUERY HANDLER ==========
bot.on('callback_query', async (callbackQuery) => {
  const msg = callbackQuery.message;
  const data = callbackQuery.data;
  const userId = callbackQuery.from.id;
  const chatId = msg.chat.id;

  if (data && data.startsWith('copy_code_')) {
    const code = data.replace('copy_code_', '');
    await bot.answerCallbackQuery(callbackQuery.id, { 
      text: `✅ Code copied: ${code}`, 
      show_alert: true
    });
    return;
  }

  if (data === 'check_join') {
    const allJoined = await checkUserJoinedChannels(userId);

    if (allJoined) {
      await bot.answerCallbackQuery(callbackQuery.id, { 
        text: '✅ Thanks for joining! Now use /pair command.', 
        show_alert: true
      });
      await bot.sendMessage(chatId, '✅ *Thanks for joining all channels!*\n\nNow send /pair to start pairing.', { parse_mode: 'Markdown' });
    } else {
      await bot.answerCallbackQuery(callbackQuery.id, { 
        text: '❌ Please join all channels first!', 
        show_alert: true
      });
    }
    return;
  }
});

// ========== TEXT MESSAGE HANDLER ==========
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text;
  
  if (msg.chat.type !== 'private') return;
  if (!text) return;
  if (text.startsWith('/')) return;
  
  const userState = userStates.get(userId);
  if (!userState || userState.step !== 'awaiting_number') return;
  
  const phoneRegex = /^\d{7,15}$/;
  if (!phoneRegex.test(text)) return;
  
  userStates.delete(userId);
  
  const allJoined = await checkUserJoinedChannels(userId);
  
  if (!allJoined) {
    return bot.sendMessage(chatId,
      `🚨 *You must join our official channels before pairing.*`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '📢 Channel 1', url: 'https://t.me/Afghan_Tech_910' }],
            [{ text: '📢 Channel 2', url: 'https://t.me/AFG_HACK_1387' }],
              [{ text: '✅ I have joined', callback_data: 'check_join' }]
          ]
        }
      }
    );
  }

  if (/[a-z]/i.test(text)) {
    return bot.sendMessage(chatId, '❌ Letters are not allowed. Send only numbers.');
  }
  
  if (text.startsWith('0')) {
    return bot.sendMessage(chatId, '❌ Numbers starting with 0 are not allowed.');
  }

  const countryCode = text.slice(0, 3);
  if (["252", "201"].includes(countryCode)) {
    return bot.sendMessage(chatId, '❌ Numbers with this country code are not supported.');
  }

  const cooldownLeft = pairingCooldownRemaining(userId);
  if (cooldownLeft > 0) return bot.sendMessage(chatId, 'لطفاً پیش از درخواست دوباره کمی صبر کنید.');

  const pairingFolder = path.join(__dirname, 'kingbadboitimewisher', 'pairing');
  if (!(await exists(pairingFolder))) {
    await fs.mkdir(pairingFolder, { recursive: true });
  }

  const files = await fs.readdir(pairingFolder);
  const pairedCount = files.filter(f => f.endsWith('@s.whatsapp.net')).length;

  if (pairedCount >= 1000) {
    return bot.sendMessage(chatId, '❌ Pairing limit reached. Try again later.');
  }

  try {
    const startpairing = require('./pair.js');
    const Xreturn = text + "@s.whatsapp.net";

    await bot.sendMessage(chatId, '⏳ Generating pairing code...');
    
    const socket = await startpairing(Xreturn);
    const cuObj = await socket.pairingCode;
    if (!cuObj || cuObj.number !== Xreturn) throw new Error('Pairing code unavailable for this request.');
    savePairingOwner(Xreturn, userId);

    return bot.sendMessage(chatId,
      `🔗 *Pairing Code*\n\n📝 Code: \`${cuObj.code}\`\n\n1. Open WhatsApp\n2. Settings → Linked Devices\n3. Link a Device\n4. Enter this code`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: `📋 Copy: ${cuObj.code}`, callback_data: `copy_code_${cuObj.code}` }]
          ]
        }
      }
    );

  } catch (error) {
    console.error('PAIRING ERROR:', error);
    bot.sendMessage(chatId, '❌ Pairing failed. Try again later.');
  }
});

// ========== SECURE UNPAIR COMMAND ==========
bot.onText(/\/unpair(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const telegramUserId = msg.from.id;
  const input = match[1]?.trim();
  if (msg.chat.type === 'group' || msg.chat.type === 'supergroup') {
    return bot.sendMessage(chatId, 'لطفاً دستور /unpair را در گفت‌وگوی خصوصی اجرا کنید.');
  }
  if (!input || !/^\d{7,15}$/.test(input) || input.startsWith('0')) {
    return bot.sendMessage(chatId, 'نمونه: /unpair 93xxxxxxxxx');
  }
  const jid = `${input}@s.whatsapp.net`;
  if (!canManagePairing(telegramUserId, jid)) {
    return bot.sendMessage(chatId, 'اجازهٔ حذف این نشست را ندارید؛ فقط مالک ثبت‌شده یا مدیر ربات مجاز است.');
  }
  try {
    const pairingPath = path.join(__dirname, 'kingbadboitimewisher', 'pairing');
    const targetPath = path.join(pairingPath, jid);
    if (!(await exists(targetPath))) return bot.sendMessage(chatId, 'برای این شماره نشست ذخیره‌شده‌ای پیدا نشد.');
    const startpairing = require('./pair.js');
    const result = await startpairing.stopPairing(jid);
    removePairingOwner(jid);
    if (result.remoteLoggedOut) return bot.sendMessage(chatId, 'نشست از واتساپ خارج و از این سرور حذف شد.');
    return bot.sendMessage(chatId, 'اطلاعات محلی نشست حذف شد؛ برای لغو کامل دستگاه، آن را از واتساپ ← دستگاه‌های متصل جدا کنید.');
  } catch (err) {
    console.error('Unpair operation failed:', err.message);
    return bot.sendMessage(chatId, 'حذف نشست کامل نشد. لطفاً دستگاه متصل را از واتساپ بررسی کنید.');
  }
});

// ========== POLLING ERROR HANDLER ==========
bot.on('polling_error', (error) => {
  console.error('Polling error:', error);
});

// ========== BOT START ==========
(async () => {
  await loadAdminIDs();
  await loadUsers();
  
  const restartCount = parseInt(process.env.RESTART_COUNT || 0);
  console.log(`RESTART #${restartCount + 1}`);
  process.env.RESTART_COUNT = String(restartCount + 1);

  console.log('🤖 Telegram Bot is running...');
  console.log('✅ Bot Username: @AJP_number_bot');
  console.log('✅ Features: /pair, /unpair, /start');
})();

// ========== PROCESS HANDLERS ==========
process.on("uncaughtException", (err) => {
  console.error('Uncaught Exception:', err);
});
process.on("unhandledRejection", (err) => {
  console.error('Unhandled Rejection:', err);
});
process.removeAllListeners("warning");
process.once('SIGINT', () => gracefulShutdown('SIGINT'));
process.once('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('message', (msg) => {
  if (msg === 'shutdown') gracefulShutdown('PM2_SHUTDOWN');
});
