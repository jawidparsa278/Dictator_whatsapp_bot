const fs = require('fs');
const path = require('path');
const SETTINGS_PATH = path.join(__dirname, 'setting.json');
let settings = {};

try {
  if (fs.existsSync(SETTINGS_PATH)) {
    const parsed = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8') || '{}');
    settings = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } else {
    fs.writeFileSync(SETTINGS_PATH, '{}\n', { mode: 0o600 });
  }
} catch (error) {
  console.error('Failed to load bot settings; using defaults:', error.message);
  settings = {};
}

function saveSettings() {
  const tempPath = `${SETTINGS_PATH}.${process.pid}.tmp`;
  fs.writeFileSync(tempPath, `${JSON.stringify(settings, null, 2)}\n`, { mode: 0o600 });
  fs.renameSync(tempPath, SETTINGS_PATH);
  try { fs.chmodSync(SETTINGS_PATH, 0o600); } catch (_) {}
}

function getSetting(jid, key, defaultValue = false) {
  if (!settings[jid]) return defaultValue;
  return settings[jid][key] !== undefined ? settings[jid][key] : defaultValue;
}

function setSetting(jid, key, value) {
  if (!settings[jid]) settings[jid] = {};
  settings[jid][key] = value;
  saveSettings();
}

module.exports = { getSetting, setSetting };
