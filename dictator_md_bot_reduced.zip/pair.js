require('dotenv').config();
const {
    default: makeWASocket,
    jidDecode,
    DisconnectReason,
    PHONENUMBER_MCC,
    makeCacheableSignalKeyStore,
    useMultiFileAuthState,
    Browsers,
    getContentType,
    proto,
    downloadContentFromMessage,
    fetchLatestBaileysVersion,
    makeInMemoryStore,
    generateWAMessageContent  
} = require("@whiskeysockets/baileys");
const handleMessage = require("./drenox");
const NodeCache = require("node-cache");
const _ = require('lodash')
const {
    Boom
} = require('@hapi/boom')
const PhoneNumber = require('awesome-phonenumber')
// Pairing codes are generated per caller-supplied number; no personal number is embedded.
const pairingCode = true;
const useMobile = process.argv.includes("--mobile");
const pino = require('pino')
const FileType = require('file-type')
const fs = require('fs')
const path = require('path')
let themeemoji = "😎";
const chalk = require('chalk')
const { writeExif, imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./allfunc/exif');
const { isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch } = require('./allfunc/myfunc')

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const store = makeInMemoryStore ? makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) }) : null;
let msgRetryCounterCache;

const rentbotTracker = new Map();
const MAX_RECONNECT_ATTEMPTS = 5;
const MAX_CONCURRENT_CONNECTIONS = 1;
const CONNECTION_DELAY = 15000;

const connectionQueue = [];
const pendingPairings = new Set();
let activeConnections = 0;

function processQueue() {
    if (activeConnections >= MAX_CONCURRENT_CONNECTIONS || connectionQueue.length === 0) return;
    activeConnections++;
    const { kingbadboiNumber, resolve, reject } = connectionQueue.shift();
    startpairingNow(kingbadboiNumber)
        .then(resolve, reject)
        .finally(() => {
            activeConnections--;
            pendingPairings.delete(kingbadboiNumber);
            setTimeout(processQueue, CONNECTION_DELAY);
        });
}

function queuePairing(kingbadboiNumber) {
    const tracker = rentbotTracker.get(kingbadboiNumber);
    const state = tracker?.connection?.ws?.readyState;
    if (pendingPairings.has(kingbadboiNumber) || tracker?.starting ||
        (tracker?.connection && !tracker.disconnected && (state === undefined || state < 2))) {
        return Promise.reject(new Error('A connection is already active, queued, or starting for this account.'));
    }
    pendingPairings.add(kingbadboiNumber);
    return new Promise((resolve, reject) => {
        connectionQueue.push({ kingbadboiNumber, resolve, reject });
        processQueue();
    });
}

function deleteFolderRecursive(folderPath) {
    if (fs.existsSync(folderPath)) {
        fs.readdirSync(folderPath).forEach(file => {
            const curPath = path.join(folderPath, file);
            if (fs.lstatSync(curPath).isDirectory()) {
                deleteFolderRecursive(curPath);
            } else {
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(folderPath);
    }
}

async function validateSession(kingbadboiNumber) {
    const sessionPath = `./kingbadboitimewisher/pairing/${kingbadboiNumber}`;
    const credsPath = path.join(sessionPath, 'creds.json');
    
    if (!fs.existsSync(credsPath)) {
        console.log(chalk.yellow(`⚠️ No creds.json for ${kingbadboiNumber}`));
        return false;
    }
    
    try {
        const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
        if (!creds.me || !creds.me.id) {
            console.log(chalk.yellow(`⚠️ Invalid session for ${kingbadboiNumber}, cleaning up...`));
            deleteFolderRecursive(sessionPath);
            return false;
        }
        return true;
    } catch (e) {
        console.log(chalk.red(`❌ Corrupt session for ${kingbadboiNumber}: ${e.message}`));
        deleteFolderRecursive(sessionPath);
        return false;
    }
}

function forceCleanupSession(kingbadboiNumber) {
    const sessionPath = `./kingbadboitimewisher/pairing/${kingbadboiNumber}`;
    
    try {
        if (fs.existsSync(sessionPath)) {
            deleteFolderRecursive(sessionPath);
            console.log(chalk.red(`🗑️ Force cleaned: ${kingbadboiNumber}`));
        }
        
        if (rentbotTracker.has(kingbadboiNumber)) {
            const tracker = rentbotTracker.get(kingbadboiNumber);
            if (tracker.connection) {
                try {
                    tracker.connection.end();
                    tracker.connection.ws?.close();
                } catch (e) {
                    // Ignore
                }
            }
            rentbotTracker.delete(kingbadboiNumber);
        }
        
        return true;
    } catch (e) {
        console.log(chalk.red(`❌ Error force cleaning ${kingbadboiNumber}: ${e.message}`));
        return false;
    }
}

// Authentication folders are user data; never expire them by directory mtime.
function ensureDirectoryExists(dirPath) {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
        console.log(chalk.blue(`📁 Created directory: ${dirPath}`));
    }
}

async function startpairingNow(kingbadboiNumber) {
    ensureDirectoryExists('./kingbadboitimewisher/pairing');

    if (!rentbotTracker.has(kingbadboiNumber)) {
        rentbotTracker.set(kingbadboiNumber, {
            connection: null,
            retryCount: 0,
            disconnected: false,
            connectedAt: null,
            eventsInitialized: false,
            preserveSession: false,
            starting: false,
            lastActivity: Date.now()
        });
    }

    const tracker = rentbotTracker.get(kingbadboiNumber);
    const socketState = tracker.connection?.ws?.readyState;
    if (tracker.starting) {
        throw new Error('A connection attempt is already in progress for this account.');
    }
    if (tracker.connection && !tracker.disconnected && (socketState === undefined || socketState < 2)) {
        throw new Error('A connection is already active or connecting for this account.');
    }

    tracker.starting = true;
    tracker.disconnected = false;
    tracker.preserveSession = false;
    tracker.lastActivity = Date.now();

    let bad;
    let state;
    let saveCreds;
    try {
        const { version } = await fetchLatestBaileysVersion();
        const sessionPath = path.join('./kingbadboitimewisher/pairing', kingbadboiNumber);
        fs.mkdirSync(sessionPath, { recursive: true, mode: 0o700 });
        try { fs.chmodSync(sessionPath, 0o700); } catch (_) {}
        ({ state, saveCreds } = await useMultiFileAuthState(sessionPath));

        bad = makeWASocket({
            logger: pino({ level: "silent" }),
            printQRInTerminal: false,
            auth: state,
            version,
            browser: Browsers.ubuntu("Edge"),
            getMessage: async key => {
                if (!store) return { conversation: '' };
                const jid = key.remoteJid;
                const msg = await store.loadMessage(jid, key.id);
                return msg?.message || '';
            },
            shouldSyncHistoryMessage: msg => {
                console.log(`\x1b[32mLoading Chat [${msg.progress}%]\x1b[39m`);
                return !!msg.syncType;
            },
            connectTimeoutMs: 60000,
            defaultQueryTimeoutMs: 60000,
            keepAliveIntervalMs: 30000,
            emitOwnEvents: true,
            fireInitQueries: true,
            generateHighQualityLinkPreview: true,
            syncFullHistory: false,
            markOnlineOnConnect: false,
        });
        tracker.connection = bad;
    } catch (error) {
        tracker.starting = false;
        tracker.connection = null;
        throw error;
    }
    tracker.starting = false;

    if (store) store.bind(bad.ev);

    bad.pairingCode = Promise.resolve(null);
    if (pairingCode && !state.creds.registered) {
        if (useMobile) throw new Error('Cannot use pairing code with mobile API');
        const phoneNumber = kingbadboiNumber.replace(/[^0-9]/g, '');
        if (!phoneNumber) throw new Error('Invalid phone number');
        bad.pairingCode = (async () => {
            await sleep(3000);
            let code = await bad.requestPairingCode(phoneNumber, 'SHADOWMD');
            code = code?.match(/.{1,4}/g)?.join('-') || code;
            if (!code) return null;
            return { number: kingbadboiNumber, code, timestamp: Date.now() };
        })().catch(err => {
            console.error(`Pairing-code request failed: ${err.message}`);
            return null;
        });
    }

    bad.newsletterMsg = async (key, content = {}, timeout = 5000) => {
        const { type: rawType = 'INFO', name, description = '', picture = null, react, id, newsletter_id = key, ...media } = content;
        const type = rawType.toUpperCase();
        if (react) {
            if (!(newsletter_id.endsWith('@newsletter') || !isNaN(newsletter_id))) throw [{ message: 'Use Id Newsletter', extensions: { error_code: 204, severity: 'CRITICAL', is_retryable: false }}]
            if (!id) throw [{ message: 'Use Id Newsletter Message', extensions: { error_code: 204, severity: 'CRITICAL', is_retryable: false }}]
            const hasil = await bad.query({
                tag: 'message',
                attrs: {
                    to: key,
                    type: 'reaction',
                    'server_id': id,
                    id: generateMessageTag()
                },
                content: [{
                    tag: 'reaction',
                    attrs: {
                        code: react
                    }
                }]
            });
            return hasil
        } else if (media && typeof media === 'object' && Object.keys(media).length > 0) {
            const msg = await generateWAMessageContent(media, { upload: bad.waUploadToServer });
            const anu = await bad.query({
                tag: 'message',
                attrs: { to: newsletter_id, type: 'text' in media ? 'text' : 'media' },
                content: [{
                    tag: 'plaintext',
                    attrs: /image|video|audio|sticker|poll/.test(Object.keys(media).join('|')) ? { mediatype: Object.keys(media).find(key => ['image', 'video', 'audio', 'sticker','poll'].includes(key)) || null } : {},
                    content: proto.Message.encode(msg).finish()
                }]
            })
            return anu
        } else {
            if ((/(FOLLOW|UNFOLLOW|DELETE)/.test(type)) && !(newsletter_id.endsWith('@newsletter') || !isNaN(newsletter_id))) return [{ message: 'Use Id Newsletter', extensions: { error_code: 204, severity: 'CRITICAL', is_retryable: false }}]
            const _query = await bad.query({
                tag: 'iq',
                attrs: {
                    to: 's.whatsapp.net',
                    type: 'get',
                    xmlns: 'w:mex'
                },
                content: [{
                    tag: 'query',
                    attrs: {
                        query_id: type == 'FOLLOW' ? '9926858900719341' : type == 'UNFOLLOW' ? '7238632346214362' : type == 'CREATE' ? '6234210096708695' : type == 'DELETE' ? '8316537688363079' : '6563316087068696'
                    },
                    content: new TextEncoder().encode(JSON.stringify({
                        variables: /(FOLLOW|UNFOLLOW|DELETE)/.test(type) ? { newsletter_id } : type == 'CREATE' ? { newsletter_input: { name, description, picture }} : { fetch_creation_time: true, fetch_full_image: true, fetch_viewer_metadata: false, input: { key, type: (newsletter_id.endsWith('@newsletter') || !isNaN(newsletter_id)) ? 'JID' : 'INVITE' }}
                    }))
                }]
            }, timeout);
            const res = JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_join_v2 || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_leave_v2 || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_create || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_delete_v2 || JSON.parse(_query.content[0].content)?.errors || JSON.parse(_query.content[0].content)
            res.thread_metadata ? (res.thread_metadata.host = 'https://mmg.whatsapp.net') : null
            return res
        }
    }

    bad.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && `${decode.user}@${decode.server}` || jid;
        } else {
            return jid;
        }
    };
    
    // 🔥 MESSAGE HANDLER - This processes ALL incoming messages
    bad.ev.on('messages.upsert', async chatUpdate => {
        try {
            const badboijid = chatUpdate.messages[0];
            if (!badboijid.message) return;
            
            badboijid.message = (Object.keys(badboijid.message)[0] === 'ephemeralMessage') 
                ? badboijid.message.ephemeralMessage.message 
                : badboijid.message;
            
            let botNumber = await bad.decodeJid(bad.user.id);
            let antiswview = global.db?.data?.settings?.[botNumber]?.antiswview || false;
            
            // Auto-read status
            if (antiswview) {
                if (badboijid.key && badboijid.key.remoteJid === 'status@broadcast'){  
                    await bad.readMessages([badboijid.key]);
                }
            }

            // Ignore newsletter updates; the bot does not auto-follow or react to them.
            if (badboijid.key?.remoteJid?.endsWith('@newsletter')) return;
            // 🔥 REGULAR MESSAGE PROCESSING - This handles all your commands
            if (!bad.public && !badboijid.key.fromMe && chatUpdate.type === 'notify') return;
            if (badboijid.key.id.startsWith('BAE5') && badboijid.key.id.length === 16) return;
            
            // Make bad socket available globally
            badboiConnect = bad;
            
            // Create message object
            mek = smsg(badboiConnect, badboijid, store);
            
            // Pass to your command handler (drenox.js)
            handleMessage(badboiConnect, mek, chatUpdate, store);
            
        } catch (err) {
            console.log(chalk.red(`❌ Message handler error: ${err.message}`));
        }
    });

    bad.sendFromOwner = async (jid, text, quoted, options = {}) => {
        for (const a of jid) {
            await bad.sendMessage(a + '@s.whatsapp.net', { text, ...options }, { quoted });
        }
    }
    
    bad.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifImg(buff, options)
        } else {
            buffer = await imageToWebp(buff)
        }
        await bad.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
        .then( response => {
            fs.unlinkSync(buffer)
            return response
        })
    }

    bad.public = true
    bad.sendText = (jid, text, quoted = '', options) => bad.sendMessage(jid, { text: text, ...options }, { quoted })

    bad.getFile = async (PATH, save) => {
        let res
        let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
        let type = await FileType.fromBuffer(data) || {
            mime: 'application/octet-stream',
            ext: '.bin'
        }
        filename = path.join(__filename, '../src/' + new Date * 1 + '.' + type.ext)
        if (data && save) fs.promises.writeFile(filename, data)
        return {
            res,
            filename,
            size: await getSizeMedia(data),
            ...type,
            data
        }
    }
    
    bad.ments = (teks = "") => {
        return teks.match("@")
        ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(
            (v) => v[1] + "@s.whatsapp.net"
            )
        : [];
    };
    
    bad.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
        let type = await bad.getFile(path, true);
        let { res, data: file, filename: pathFile } = type;

        if (res && res.status !== 200 || file.length <= 65536) {
            try {
                throw {
                    json: JSON.parse(file.toString())
                };
            } catch (e) {
                if (e.json) throw e.json;
            }
        }

        let opt = {
            filename
        };

        if (quoted) opt.quoted = quoted;
        if (!type) options.asDocument = true;

        let mtype = '',
            mimetype = type.mime,
            convert;

        if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
        else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
        else if (/video/.test(type.mime)) mtype = 'video';
        else if (/audio/.test(type.mime)) {
            convert = await (ptt ? toPTT : toAudio)(file, type.ext);
            file = convert.data;
            pathFile = convert.filename;
            mtype = 'audio';
            mimetype = 'audio/ogg; codecs=opus';
        } else mtype = 'document';

        if (options.asDocument) mtype = 'document';

        delete options.asSticker;
        delete options.asLocation;
        delete options.asVideo;
        delete options.asDocument;
        delete options.asImage;

        let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
        let m;

        try {
            m = await bad.sendMessage(jid, message,  { ...opt, ...options });
        } catch (e) {
            m = null;
        } finally {
            if (!m) m = await bad.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
            file = null;
            return m;
        }
    }

    bad.sendTextWithMentions = async (jid, text, quoted, options = {}) => bad.sendMessage(jid, { text: text, mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), ...options }, { quoted })

    bad.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(quoted, messageType)
        let buffer = Buffer.from([])
        for await(const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }
        let type = await FileType.fromBuffer(buffer)
        let trueFileName = attachExtension ? ('./sticker/' + filename + '.' + type.ext) : './sticker/' + filename
        await fs.writeFileSync(trueFileName, buffer)
        return trueFileName
    }

    bad.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(message, messageType)
        let buffer = Buffer.from([])
        for await(const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }
        return buffer
    }

    // 🔥 ENHANCED CONNECTION HANDLER WITH KEEP-ALIVE
    bad.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect } = update;
        const tracker = rentbotTracker.get(kingbadboiNumber);

        if (connection === "close") {
            tracker.eventsInitialized = false;
            let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            console.log(chalk.yellow(`🔌 Connection closed for ${kingbadboiNumber}, reason: ${reason}`));

            if (reason === 405) {
                console.log(chalk.red.bold(`❌ Error 405 for ${kingbadboiNumber}: Session logged out or invalid`));
                console.log(chalk.yellow(`🗑️ Force cleaning session for ${kingbadboiNumber}...`));
                
                forceCleanupSession(kingbadboiNumber);
                
                tracker.disconnected = true;
                tracker.connection = null;
                
                console.log(chalk.red(`🚫 ${kingbadboiNumber} will NOT reconnect. User must re-pair.`));
                return;
            } else if (reason === 440) {
                tracker.disconnected = true;
                tracker.preserveSession = true;
                tracker.connection = null;
                console.warn(chalk.yellow(`⚠️ Multi-device conflict (440) for ${kingbadboiNumber}. Automatic retries stopped; check Linked Devices in WhatsApp before reconnecting.`));
                return;
            } else if (reason === DisconnectReason.badSession) {
                console.log(chalk.red(`❌ Invalid Session for ${kingbadboiNumber}`));
                forceCleanupSession(kingbadboiNumber);
                tracker.disconnected = true;
            } else if (reason === DisconnectReason.loggedOut) {
                console.log(chalk.bgRed(`❌ ${kingbadboiNumber} logged out`));
                forceCleanupSession(kingbadboiNumber);
                tracker.disconnected = true;
            } else if (reason === DisconnectReason.connectionClosed ||
                       reason === DisconnectReason.connectionLost ||
                       reason === DisconnectReason.timedOut) {
                const isValid = await validateSession(kingbadboiNumber);
                if (!isValid) {
                    tracker.disconnected = true;
                    tracker.connection = null;
                    console.log(chalk.red(`❌ Invalid session for ${kingbadboiNumber}; automatic reconnect stopped.`));
                    return;
                }
                // Reset the reconnect budget only after a stable connection lasting at least 5 minutes.
                if (tracker.connectedAt && Date.now() - tracker.connectedAt >= 5 * 60 * 1000) {
                    tracker.retryCount = 0;
                }
                tracker.connectedAt = null;
                if (tracker.retryCount < MAX_RECONNECT_ATTEMPTS) {
                    const delayMs = Math.min(15000 * (2 ** Math.max(0, tracker.retryCount - 1)), 5 * 60 * 1000);
                    console.log(chalk.yellow(`🔄 Temporary connection loss for ${kingbadboiNumber}; retrying in ${Math.round(delayMs / 1000)}s (${tracker.retryCount}/${MAX_RECONNECT_ATTEMPTS}).`));
                    await sleep(delayMs);
                    tracker.retryCount++;
                    queuePairing(kingbadboiNumber);
                } else {
                    tracker.disconnected = true;
                    tracker.preserveSession = true;
                    tracker.connection = null;
                    console.log(chalk.red(`❌ Reconnect limit reached for ${kingbadboiNumber}; stopped to avoid repeated connection attempts.`));
                }
            } else if (reason === DisconnectReason.restartRequired) {
                if (tracker.retryCount < MAX_RECONNECT_ATTEMPTS) {
                    console.log(chalk.blue(`🔄 Restart required for ${kingbadboiNumber}; reconnecting once.`));
                    await sleep(5000);
                    tracker.retryCount++;
                    queuePairing(kingbadboiNumber);
                } else {
                    tracker.disconnected = true;
                    tracker.preserveSession = true;
                    tracker.connection = null;
                    console.log(chalk.red(`❌ Reconnect limit reached for ${kingbadboiNumber}; stopped.`));
                }
            } else {
                tracker.disconnected = true;
                tracker.preserveSession = true;
                tracker.connection = null;
                console.log(chalk.magenta(`❓ Unhandled disconnect reason ${reason} for ${kingbadboiNumber}; automatic retries stopped.`));
            }
        } else if (connection === "open") {
            console.log(chalk.bgGreen.black(`✅ Connected: ${kingbadboiNumber}`));
            tracker.disconnected = false;
            tracker.connectedAt = Date.now();
            tracker.lastActivity = Date.now();
            // Register group event handlers once per active socket; no post-connect follows, joins or reactions.
            if (!tracker.eventsInitialized) {
                const drenoxModule = require('./drenox');
                if (drenoxModule.setupEventListeners && typeof drenoxModule.setupEventListeners === 'function') {
                    try {
                        drenoxModule.setupEventListeners(bad, store);
                        tracker.eventsInitialized = true;
                        console.log(chalk.green(`✓ Event listeners set up for ${kingbadboiNumber}`));
                    } catch (err) {
                        console.log(chalk.yellow(`⚠️ Event listener setup error: ${err.message}`));
                    }
                }
            }
            console.log(chalk.green(`✅ WhatsApp connection ready for ${kingbadboiNumber}`));
        } else if (connection === "connecting") {
            console.log(chalk.blue(`🔄 Connecting ${kingbadboiNumber}...`));
        }
    });

    bad.ev.on('creds.update', saveCreds);

    return bad;
}

function startpairing(kingbadboiNumber) {
    return queuePairing(kingbadboiNumber);
}
function isConnected(kingbadboiNumber) {
    const tracker = rentbotTracker.get(kingbadboiNumber);
    return Boolean(tracker && !tracker.disconnected && tracker.connection && tracker.connection.ws?.readyState === 1);
}
function isActive(kingbadboiNumber) {
    const tracker = rentbotTracker.get(kingbadboiNumber);
    const state = tracker?.connection?.ws?.readyState;
    return Boolean(pendingPairings.has(kingbadboiNumber) || (tracker && (tracker.starting || (tracker.connection && !tracker.disconnected && (state === undefined || state < 2)))));
}

async function stopPairing(kingbadboiNumber) {
    const tracker = rentbotTracker.get(kingbadboiNumber);
    let remoteLoggedOut = false;
    if (tracker?.connection) {
        tracker.disconnected = true;
        tracker.preserveSession = false;
        const connection = tracker.connection;
        if (connection.ws?.readyState === 1 && typeof connection.logout === 'function') {
            await connection.logout();
            remoteLoggedOut = true;
        }
        try { connection.end?.(); } catch (_) {}
        try { connection.ws?.close(); } catch (_) {}
    }
    const sessionPath = path.join('./kingbadboitimewisher/pairing', kingbadboiNumber);
    if (fs.existsSync(sessionPath)) deleteFolderRecursive(sessionPath);
    rentbotTracker.delete(kingbadboiNumber);
    return { remoteLoggedOut };
}

function smsg(bad, m, store) {
    if (!m) return m
    let M = proto.WebMessageInfo
    if (m.key) {
        m.id = m.key.id
        m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16
       
        m.chat = m.key.remoteJid
        m.fromMe = m.key.fromMe
        m.isGroup = m.chat.endsWith('@g.us')
        m.sender = bad.decodeJid(m.fromMe && bad.user.id || m.participant || m.key.participant || m.chat || '')
        if (m.isGroup) m.participant = bad.decodeJid(m.key.participant) || ''
    }
    if (m.message) {
        m.mtype = getContentType(m.message)
        m.msg = (m.mtype == 'viewOnceMessage' ? m.message[m.mtype]?.message?.[getContentType(m.message[m.mtype]?.message)] : m.message[m.mtype]) || {}
        m.body = m.message.conversation || m.msg?.caption || m.msg?.text || (m.mtype == 'listResponseMessage' && m.msg?.singleSelectReply?.selectedRowId) || (m.mtype == 'buttonsResponseMessage' && m.msg?.selectedButtonId) || (m.mtype == 'viewOnceMessage' && m.msg?.caption) || m.text || ''
        let quoted = m.quoted = m.msg?.contextInfo?.quotedMessage || null
        m.mentionedJid = m.msg?.contextInfo?.mentionedJid || []
        if (m.quoted) {
            let type = getContentType(quoted)
            m.quoted = m.quoted[type]
            if (['productMessage'].includes(type)) {
                type = getContentType(m.quoted)
                m.quoted = m.quoted[type]
            }
            if (typeof m.quoted === 'string') m.quoted = {
                text: m.quoted
            }
            m.quoted.mtype = type
            m.quoted.id = m.msg.contextInfo.stanzaId
            m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
            m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16 : false
            m.quoted.sender = bad.decodeJid(m.msg.contextInfo.participant)
            m.quoted.fromMe = m.quoted.sender === bad.decodeJid(bad.user.id)
            m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || ''
            m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
            m.getQuotedObj = m.getQuotedMessage = async () => {
                if (!m.quoted.id) return false
                let q = await store.loadMessage(m.chat, m.quoted.id, bad)
                return smsg(bad, q, store)
            }
            let vM = m.quoted.fakeObj = M.fromObject({
                key: {
                    remoteJid: m.quoted.chat,
                    fromMe: m.quoted.fromMe,
                    id: m.quoted.id
                },
                message: quoted,
                ...(m.isGroup ? { participant: m.quoted.sender } : {})
            })
            m.quoted.delete = () => bad.sendMessage(m.quoted.chat, { delete: vM.key })
            m.quoted.copyNForward = (jid, forceForward = false, options = {}) => bad.copyNForward(jid, vM, forceForward, options)
            m.quoted.download = () => bad.downloadMediaMessage(m.quoted)
        }
    }
    if (m.msg?.url) m.download = () => bad.downloadMediaMessage(m.msg)
    m.text = m.msg?.text || m.msg?.caption || m.message?.conversation || m.msg?.contentText || m.msg?.selectedDisplayText || m.msg?.title || ''
    m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? bad.sendMedia(chatId, text, 'file', '', m, { ...options }) : bad.sendText(chatId, text, m, { ...options })
    m.copy = () => smsg(bad, M.fromObject(M.toObject(m)), store)
    m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => bad.copyNForward(jid, m, forceForward, options)

    return m
}

exports.smsg = smsg;
startpairing.isConnected = isConnected;
startpairing.isActive = isActive;
startpairing.stopPairing = stopPairing;
startpairing.smsg = smsg;
module.exports = startpairing;

if (process.env.NODE_ENV !== 'production') {
    const file = require.resolve(__filename);
    fs.watchFile(file, () => {
        fs.unwatchFile(file);
        console.log(chalk.redBright(`Source changed: ${__filename}; restart the process to reload safely.`));
    });
}
