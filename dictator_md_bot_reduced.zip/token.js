require('dotenv').config();

const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN) {
  throw new Error('Missing BOT_TOKEN. Set it in your environment or .env file.');
}

module.exports = { BOT_TOKEN };
